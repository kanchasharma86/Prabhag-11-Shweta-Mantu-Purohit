
package com.prabhag11.app;
import android.os.Bundle;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 protected void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  w.getSettings().setJavaScriptEnabled(true);
  w.setWebViewClient(new WebViewClient());
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
}
